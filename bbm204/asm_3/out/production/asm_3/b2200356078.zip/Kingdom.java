import java.util.ArrayList;
import java.util.List;

public class Kingdom {

    // TODO: You should add appropriate instance variables.
    public void initializeKingdom(String filename) {
        // Read the txt file and fill your instance variables
        // TODO: Your code here
    }

    public List<Colony> getColonies() {
        List<Colony> colonies = new ArrayList<>();
        // TODO: DON'T READ THE .TXT FILE HERE!
        // Identify the colonies using the given input file.
        // TODO: Your code here
        return colonies;
    }

    public void printColonies(List<Colony> discoveredColonies) {
        // Print the given list of discovered colonies conforming to the given output format.
        // TODO: Your code here
    }
}
