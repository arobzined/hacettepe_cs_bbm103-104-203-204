import java.util.*;
import java.awt.*;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.io.*;

public class IMECEPathFinder {
  public int[][] grid;
  public int height, width;
  public int maxFlyingHeight;
  public double fuelCostPerUnit, climbingCostPerUnit;
  private String fileContent;

  public IMECEPathFinder(String filename, int rows, int cols, int maxFlyingHeight, double fuelCostPerUnit,
      double climbingCostPerUnit) {

    grid = new int[rows][cols];
    this.height = rows;
    this.width = cols;
    this.maxFlyingHeight = maxFlyingHeight;
    this.fuelCostPerUnit = fuelCostPerUnit;
    this.climbingCostPerUnit = climbingCostPerUnit;

    try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
      String line;
      int row_count = 0;
      while ((line = br.readLine()) != null) {
        String[] cols_w = line.split("   ");
        for (int i = 0; i < cols_w.length; i++) {
          if (i == 0) {
            continue;
          }
          this.grid[row_count][i - 1] = Integer.parseInt(cols_w[i]);
        }
        row_count++;
      }
    } catch (IOException e) {
      e.printStackTrace();
    }

    try (BufferedWriter bw = new BufferedWriter(new FileWriter("grayscaleMap.dat"))){


      double max = grid[0][0];
      double min = grid[0][0];
      for (int i = 0; i < grid.length; i++) {
        for (int j = 0; j < grid[0].length; j++) {
          max = Math.max(max, grid[i][j]);
          min = Math.min(min, grid[i][j]);
        }
      }

      double ratio = (max - min) / 255;

      for (int i = 0; i < grid.length; i++) {
        for (int j = 0; j < grid[0].length; j++) {
          int value = (int) ((grid[i][j] - min) / ratio);
          bw.write(value + " ");
          //g.setColor(new Color(value, value, value));
          //g.fillRect(j, i, 1, 1);
        }
        bw.write("\n");
      }
    }catch (IOException e){
      e.printStackTrace();
    }

  }

  /**
   * Draws the grid using the given Graphics object.
   * Colors should be grayscale values 0-255, scaled based on min/max elevation
   * values in the grid
   */
  public void drawGrayscaleMap(Graphics g) {

    // TODO: draw the grid, delete the sample drawing with random color values given
    // below
    try (BufferedWriter bw = new BufferedWriter(new FileWriter("grayscaleMap.dat"))){


      double max = grid[0][0];
      double min = grid[0][0];
      for (int i = 0; i < grid.length; i++) {
        for (int j = 0; j < grid[0].length; j++) {
          max = Math.max(max, grid[i][j]);
          min = Math.min(min, grid[i][j]);
        }
      }

      double ratio = (max - min) / 255;

      for (int i = 0; i < grid.length; i++) {
        for (int j = 0; j < grid[0].length; j++) {
          int value = (int) ((grid[i][j] - min) / ratio);
          bw.write(value + " ");
          g.setColor(new Color(value, value, value));
          g.fillRect(j, i, 1, 1);
        }
        bw.write("\n");
      }
    }catch (IOException e){
      e.printStackTrace();
    }

  }

  /**
   * Get the most cost-efficient path from the source Point start to the
   * destination Point end
   * using Dijkstra's algorithm on pixels.
   * 
   * @return the List of Points on the most cost-efficient path from start to end
   */
  public List<Point> getMostEfficientPath(Point start, Point end) {
    List<Point> path = new ArrayList<>();

    // Initialize distance array and set all values to infinity
    double[][] distance = new double[height][width];
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        distance[i][j] = Double.POSITIVE_INFINITY;
      }
    }

    // Initialize previous node array
    Point[][] previous = new Point[height][width];

    // Create a priority queue to store the points based on their distances
    PriorityQueue<Point> queue = new PriorityQueue<>(Comparator.comparingDouble(p -> distance[p.y][p.x]));

    // Set the distance of the start point to 0 and add it to the queue
    distance[start.y][start.x] = 0;
    queue.add(start);

    // Keep track of visited points

    while (!queue.isEmpty()) {
      Point current = queue.poll();

      // Check if the current point is the destination
      if (current.x == end.x && current.y == end.y) {
        // Reconstruct the path by backtracking from the destination to the start
        Point node = end;
        while (node != null) {
          path.add(0, node);
          node = previous[node.y][node.x];
        }
        return path;
      }

      // Explore the neighbors of the current point
      for (int i = -1; i < 2; i++) {
        for (int j = -1; j < 2; j++) {
          if (i == 0 && j == 0) {
            continue; // Skip the current position
          }
          Point neighbor = new Point(current.x + j, current.y + i);

          if (isValid(neighbor) && grid[current.y + i][current.x + j] <= maxFlyingHeight) {
            double cost = costPerUnit(current, neighbor);
            double totalCost = cost + distance[current.y][current.x];
            if (totalCost < distance[neighbor.y][neighbor.x]) {
              //System.out.println();
              distance[neighbor.y][neighbor.x] = totalCost;
              previous[neighbor.y][neighbor.x] = current;
              queue.add(neighbor);
              // Check if the neighbor has already been visited
            }
          }
        }
      }
    }


    // If no path is found, return an empty list
    return path;
  }



  private boolean isValid(Point current) {
    return (current.x >= 0 && current.x < width && current.y >= 0 && current.y < height);
  }

  private double costPerUnit(Point current, Point nextMove) {
    double dist = Math.sqrt(Math.pow(current.x - nextMove.x, 2) + Math.pow(current.y - nextMove.y, 2));
    double heightImp = 0.0;
    if (grid[current.y][current.x] < grid[nextMove.y][nextMove.x]) {
      heightImp = grid[nextMove.y][nextMove.x] - grid[current.y][current.x];
    }
    return (dist * fuelCostPerUnit) + (climbingCostPerUnit * heightImp);
  }



  /*
  This was my first Dijkstra algorithm trying so i didn't want to delete it :).It helps me a lot !
  private void wonderingInSizePath(Point current, double[][] size, double cost, Point end) {

    if (current.y == end.y || current.x == end.x) {
      return;
    }
    if (size[current.y][current.x] == 0.0 || size[current.y][current.x] > cost) {
      size[current.y][current.x] = cost;
    }
    for (int i = -1; i < 2; i++) {
      for (int j = -1; j < 2; j++) {
        if (i == 0 && j == 0) {
          continue; // Skip the current position
        }
        if (isValid(new Point(current.x + j, current.y + i)) && grid[current.y + i][current.x + j] <= maxFlyingHeight) {
          Point next = new Point(current.x + j, current.y + i);
          double currCost = cost + costPerUnit(current, next);
          wonderingInSizePath(next, size, currCost, end);
        }
      }
    }
  }*/


  /**
   * Calculate the most cost-efficient path from source to destination.
   * 
   * @return the total cost of this most cost-efficient path when traveling from
   *         source to destination
   */
  public double getMostEfficientPathCost(List<Point> path) {
    double totalCost = 0.0;

    for(int i = 0;i < path.size() - 1;i++){
      totalCost += costPerUnit(path.get(i),path.get(i+1));
    };


    return totalCost;
  }

  /**
   * Draw the most cost-efficient path on top of the grayscale map from source to
   * destination.
   */
  public void drawMostEfficientPath(Graphics g, List<Point> path) {
    for(Point elm : path){
      g.setColor(new Color(0, 255, 0));
      g.fillRect(elm.x, elm.y, 1, 1);
    }
  }

  /**
   * Find an escape path from source towards East such that it has the lowest
   * elevation change.
   * Choose a forward step out of 3 possible forward locations, using greedy
   * method described in the assignment instructions.
   * 
   * @return the list of Points on the path
   */
  public List<Point> getLowestElevationEscapePath(Point start) {
    List<Point> pathPointsList = new ArrayList<>();
    // TODO: Your code goes here
    // TODO: Implement the Mission 1 greedy approach here
    pathPointsList.add(start);
    getNextMove(start,pathPointsList);
    //System.out.println(pathPointsList.get(pathPointsList.size() - 1).x + " - " + pathPointsList.get(pathPointsList.size() - 1).y);
    return pathPointsList;
  }

  public boolean isNotValid(Point curr){
    if(curr.x >= width){
      return true;
    }
    return false;
  }

  public List<Point> getNextMove(Point current,List<Point> list){
    Point northEast = new Point(current.x + 1, current.y - 1);
    Point east = new Point(current.x + 1, current.y);
    Point southEast = new Point(current.x + 1, current.y + 1);

    if(isNotValid(northEast)){
      return list;
    }

    Point nextMove = compareInts(northEast,east,southEast,current);

    list.add(nextMove);
    return getNextMove(nextMove, list);
  }

  public Point compareInts(Point northEast,Point east, Point southEast,Point curr){
    int currentH = grid[curr.y][curr.x];

    int h1 = Math.abs(currentH - grid[northEast.y][northEast.x]);
    int h2 = Math.abs(currentH - grid[east.y][east.x]);
    int h3 = Math.abs(currentH - grid[southEast.y][southEast.x]);

    if(h1 < h2 && h1 < h3){
      return northEast;
    }
    else if(h2 < h1 && h2 < h3){
      return east;
    }
    else if(h3 < h2 && h3 < h1){
      return southEast;
    }
    else{
      if(h1 == h3 && h1 == h2){
        return east;
      }
      else{
        if(h1 == h2){
          return east;
        }
        else if(h1 == h3){
          return northEast;
        }
        else {
          return east;
        }
      }
    }
  }



  /**
   * Calculate the escape path from source towards East such that it has the
   * lowest elevation change.
   * 
   * @return the total change in elevation for the entire path
   */
  public int getLowestElevationEscapePathCost(List<Point> pathPointsList) {
    int totalChange = 0;

    // TODO: Your code goes here, use the output from the
    for(int i = 0;i < pathPointsList.size() - 1;i++){
      totalChange += Math.abs(grid[pathPointsList.get(i).y][pathPointsList.get(i).x] -
              grid[pathPointsList.get(i+1).y][pathPointsList.get(i+1).x]);
    }

    return totalChange;
  }

  /**
   * Draw the escape path from source towards East on top of the grayscale map
   * such that it has the lowest elevation change.
   */
  public void drawLowestElevationEscapePath(Graphics g, List<Point> pathPointsList) {
    for(Point elm : pathPointsList){
      g.setColor(new Color(255, 255, 0));
      g.fillRect(elm.x, elm.y, 1, 1);
    }

  }


}
