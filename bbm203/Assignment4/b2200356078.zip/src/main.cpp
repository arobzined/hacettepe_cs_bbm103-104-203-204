#include <iostream>
#include "Webstore.h"

int main(int argc,char* argv[]) {
    Webstore webstore;
    string inputtxt = argv[1];
    string outputtxt = argv[2];
    string dghfgdshaf = argv[3];
    webstore.read_input(inputtxt,outputtxt);
    return 0;
}
